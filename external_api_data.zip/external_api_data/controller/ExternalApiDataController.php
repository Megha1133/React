<?php

namespace Drupal\external_api_data\Controller;

use Drupal\Core\Controller\ControllerBase;
use GuzzleHttp\Client;
use Symfony\Component\DependencyInjection\ContainerInterface;

class ExternalApiDataController extends ControllerBase {

  protected $httpClient;

  public function __construct(Client $http_client) {
    $this->httpClient = $http_client;
  }

  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('http_client')
    );
  }

  public function content() {
    // Replace with your external API URL.
    $api_url = 'https://api.example.com/data';

    try {
      $response = $this->httpClient->get($api_url);
      $data = json_decode($response->getBody(), TRUE);
    } catch (\Exception $e) {
      watchdog_exception('external_api_data', $e);
      $data = ['error' => 'Could not fetch data from API.'];
    }

    return [
      '#theme' => 'item_list',
      '#items' => $data,
      '#title' => $this->t('External API Data'),
    ];
  }
}
