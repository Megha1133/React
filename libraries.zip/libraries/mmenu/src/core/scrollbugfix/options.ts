const options : mmOptionsScrollbugfix = {
	fix: true
};
export default options;
