export default {
	'Close menu': 'Menü schließen',
    'Open menu': 'Menü öffnen',
}