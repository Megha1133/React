export default {
    'Close menu': 'بستن منو',
    'Open menu': 'باز کردن منو',
}