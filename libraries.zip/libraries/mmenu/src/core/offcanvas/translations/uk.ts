export default {
    'Close menu': 'Закрити меню',
    'Open menu': 'Відкрити меню',
}