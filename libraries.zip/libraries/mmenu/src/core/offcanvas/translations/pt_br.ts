export default {
    'Close menu': 'Fechar menu',
    'Open menu': 'Abrir menu',
}