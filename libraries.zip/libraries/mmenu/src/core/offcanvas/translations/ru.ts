export default {
    'Close menu': 'Закрыть меню',
    'Open menu': 'открыть меню',
}