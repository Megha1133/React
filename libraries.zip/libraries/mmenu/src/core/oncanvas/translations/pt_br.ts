export default {
    'Close submenu': 'Fechar submenu',
	'Menu': 'Menu',
    'Open submenu': 'Abrir submenu',
    'Toggle submenu': 'Alternar submenu'
};
