const options : mmOptionsTheme = 'light';

export default options;
