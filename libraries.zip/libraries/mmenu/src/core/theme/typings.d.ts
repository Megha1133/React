/** Possible positions for the menu. */
type mmOptionsTheme = 'light' | 'dark' | 'white' | 'black' | 'light-contrast' | 'dark-contrast' | 'white-contrast' | 'black-contrast'
