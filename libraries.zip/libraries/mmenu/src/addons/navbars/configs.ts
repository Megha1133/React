const configs : mmConfigsNavbars = {
	breadcrumbs: {
		separator: '/',
		removeFirst: false
	}
};
export default configs;