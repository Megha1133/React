const options : mmOptionsSectionindexer = {
	add: false,
	addTo: 'panels'
};

export default options;
