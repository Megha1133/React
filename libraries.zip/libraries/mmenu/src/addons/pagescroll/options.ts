const options : mmOptionsPagescroll = {
	scroll: false,
	update: false
};

export default options;
