const options: mmOptionsCounters = {
    add: false
};

export default options;
