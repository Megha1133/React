export default {
    'cancel': 'annuleren',
    'Cancel searching': 'Zoeken annuleren',
    'Clear searchfield': 'Zoekveld leeg maken',
    'No results found.': 'Geen resultaten gevonden.',
    'Search': 'Zoeken',
};
