export default {
    'cancel': 'zrušiť',
    'Cancel searching': 'Zrušiť vyhľadávanie',
    'Clear searchfield': 'Vymazať pole vyhľadávania',
    'No results found.': 'Neboli nájdené žiadne výsledky.',
    'Search': 'Vyhľadávanie',
}