const configs : mmConfigsSearchfield = {
	cancel: true,
	clear: true,
	form: {},
	input: {},
	panel: {},
	submit: false
};
export default configs;